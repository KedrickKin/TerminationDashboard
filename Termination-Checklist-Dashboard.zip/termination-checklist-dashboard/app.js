const STORAGE_KEY = "termination-checklist-dashboard.records.v2";
const LEGACY_STORAGE_KEY = "termination-checklist-dashboard.records.v1";
const DEMO_EMPLOYEE_IDS = new Set(["E-10429", "E-09814", "E-11207", "E-08731"]);
const JOHN_DOE_NAME = "john doe";

const STATUS_OPTIONS = ["Open", "In Progress", "Blocked", "Complete", "N/A"];

const CHECKLIST_ITEMS = [
  { id: "it", label: "IT", category: "Access", critical: true },
  { id: "dayforce", label: "Dayforce", category: "Systems", critical: true },
  { id: "badge", label: "Badge", category: "Physical", critical: true },
  { id: "cleanout", label: "Office cleanout", category: "Workspace", critical: false },
  { id: "tuition", label: "Pending tuition check reimbursement", category: "Finance", finance: true, conditional: "tuition" },
  { id: "bonus", label: "Track one-year sign-on bonus", category: "Finance", finance: true, conditional: "bonus" },
  { id: "clearance", label: "Security clearance readout, if necessary", category: "Security", critical: true, clearance: true, conditional: "clearance" },
  { id: "pto", label: "Overdrawn paid time off", category: "Finance", finance: true, conditional: "pto" }
];

let employees = [];
let expandedEmployeeIds = new Set();
let editingEmployeeId = null;
let workbookHandle = null;
let workbookBaselineRecords = null;
let workbookLinkRestorePromise = Promise.resolve();
let workbookWriteEnabled = false;
let workbookAutoSync = true;
let workbookImportBusy = false;
let workbookSaveTimer = null;
let workbookSaveQueue = Promise.resolve();

const dom = {};

document.addEventListener("DOMContentLoaded", () => {
  cacheDom();
  renderBoardHeader();
  employees = loadEmployees();

  wireEvents();
  setDefaultTerminationDate();
  updateConditionalFields();
  render();
  workbookLinkRestorePromise = restoreExcelLink();
});

function cacheDom() {
  dom.kpiGrid = document.querySelector("#kpiGrid");
  dom.boardHeader = document.querySelector("#boardHeader");
  dom.checklistBody = document.querySelector("#checklistBody");
  dom.employeeForm = document.querySelector("#employeeForm");
  dom.employeeFormEyebrow = document.querySelector("#employeeFormEyebrow");
  dom.employeeFormTitle = document.querySelector("#employeeFormTitle");
  dom.employeeSubmitButton = document.querySelector("#employeeSubmitButton");
  dom.cancelEditButton = document.querySelector("#cancelEditButton");
  dom.loadExcel = document.querySelector("#loadExcel");
  dom.saveExcel = document.querySelector("#saveExcel");
  dom.excelSyncStatus = document.querySelector("#excelSyncStatus");
  dom.excelFileFallback = document.querySelector("#excelFileFallback");
  dom.searchFilter = document.querySelector("#searchFilter");
  dom.ownerFilter = document.querySelector("#ownerFilter");
  dom.statusFilter = document.querySelector("#statusFilter");
  dom.criticalOnlyFilter = document.querySelector("#criticalOnlyFilter");
  dom.clearFilters = document.querySelector("#clearFilters");
  dom.exportCsv = document.querySelector("#exportCsv");
  dom.recordCount = document.querySelector("#recordCount");
  dom.lastSaved = document.querySelector("#lastSaved");
}

function wireEvents() {
  dom.employeeForm.addEventListener("submit", saveEmployeeForm);
  dom.employeeForm.addEventListener("reset", () => {
    editingEmployeeId = null;
    setEmployeeFormMode(false);
    window.setTimeout(() => {
      setDefaultTerminationDate();
      updateConditionalFields();
    }, 0);
  });
  dom.cancelEditButton.addEventListener("click", cancelEdit);

  dom.employeeForm.querySelectorAll("[data-conditional-target]").forEach((toggle) => {
    toggle.addEventListener("change", updateConditionalFields);
  });

  [dom.searchFilter, dom.ownerFilter, dom.statusFilter, dom.criticalOnlyFilter].forEach((control) => {
    control.addEventListener("input", render);
    control.addEventListener("change", render);
  });

  dom.clearFilters.addEventListener("click", () => {
    dom.searchFilter.value = "";
    dom.ownerFilter.value = "All";
    dom.statusFilter.value = "All";
    dom.criticalOnlyFilter.checked = false;
    render();
  });

  dom.exportCsv.addEventListener("click", exportCsv);
  dom.loadExcel.addEventListener("click", loadTermChecklistFromExcel);
  dom.saveExcel.addEventListener("click", saveTermChecklistToExcel);
  dom.excelFileFallback.addEventListener("change", loadFallbackExcelFile);

  dom.checklistBody.addEventListener("change", updateChecklistField);
  dom.checklistBody.addEventListener("change", completeTermFromCheckbox);
  dom.checklistBody.addEventListener("click", toggleEmployeeExpansion);
  dom.checklistBody.addEventListener("click", focusEmployeeForm);
  dom.checklistBody.addEventListener("click", handleEmployeeActions);
}

function loadEmployees() {
  try {
    const currentStored = window.localStorage.getItem(STORAGE_KEY);
    if (currentStored) {
      const parsedEmployees = JSON.parse(currentStored);
      const currentEmployees = removeJohnDoeRecords(parsedEmployees);
      const originalCount = Array.isArray(parsedEmployees) ? parsedEmployees.length : 0;
      if (currentEmployees.length !== originalCount) {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(currentEmployees));
      }
      return currentEmployees;
    }

    const legacyStored = window.localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!legacyStored) return [];

    const legacyEmployees = JSON.parse(legacyStored);
    const cleanedEmployees = Array.isArray(legacyEmployees)
      ? legacyEmployees.filter((employee) => !DEMO_EMPLOYEE_IDS.has(employee.employeeId))
      : [];
    const cleanedWithoutJohnDoe = removeJohnDoeRecords(cleanedEmployees);

    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(cleanedWithoutJohnDoe));
    window.localStorage.removeItem(LEGACY_STORAGE_KEY);
    return cleanedWithoutJohnDoe;
  } catch (error) {
    console.warn("Saved dashboard data could not be loaded.", error);
    return [];
  }
}

function removeJohnDoeRecords(records) {
  return Array.isArray(records)
    ? records.filter((employee) => String(employee?.employeeName || "").trim().toLowerCase() !== JOHN_DOE_NAME)
    : [];
}

function saveEmployees() {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(employees));
    scheduleWorkbookSave();
  } catch (error) {
    window.alert("This browser could not save the latest dashboard change.");
    console.error(error);
  }
}

async function restoreExcelLink() {
  try {
    workbookHandle = await window.TermChecklistExcel.getSavedHandle();
    if (workbookHandle) {
      const savedBaseline = await window.TermChecklistExcel.getSavedBaseline().catch(() => null);
      workbookBaselineRecords = Array.isArray(savedBaseline) ? savedBaseline : null;
      setExcelSyncStatus(`${workbookHandle.name} is linked. Click Load from destination to refresh it.`);
    }
  } catch (error) {
    console.warn("The saved Excel file link is unavailable.", error);
    setExcelSyncStatus("Click Load from destination to connect Term Checklist.xlsx.", "warning");
  }
}

async function loadTermChecklistFromExcel() {
  try {
    await workbookLinkRestorePromise;
    if (!workbookHandle) {
      workbookHandle = await window.TermChecklistExcel.getSavedHandle().catch(() => null);
    }

    if (!workbookHandle && !window.showOpenFilePicker) {
      dom.excelFileFallback.value = "";
      dom.excelFileFallback.click();
      return;
    }

    if (!workbookHandle) {
      workbookHandle = await window.TermChecklistExcel.openWorkbookPicker();
      await setWorkbookBaseline(null);
      try {
        await window.TermChecklistExcel.saveHandle(workbookHandle);
      } catch (error) {
        console.warn("The workbook is linked for this browser session only.", error);
      }
    }

    const readAllowed = await requestWorkbookPermission(workbookHandle, "read");
    if (!readAllowed) throw new Error("Allow the dashboard to read Term Checklist.xlsx, then click Load from destination again.");

    workbookWriteEnabled = await requestWorkbookPermission(workbookHandle, "readwrite");
    const importedEmployees = await window.TermChecklistExcel.loadWorkbook(workbookHandle, CHECKLIST_ITEMS);
    await applyExcelRecords(importedEmployees, true);
  } catch (error) {
    if (error?.name === "AbortError") return;
    setExcelSyncStatus(error.message || "The Excel checklist could not be loaded.", "error");
  }
}

async function saveTermChecklistToExcel() {
  try {
    await workbookLinkRestorePromise;
    if (!workbookHandle) {
      workbookHandle = await window.TermChecklistExcel.getSavedHandle().catch(() => null);
    }

    if (!workbookHandle && !window.showOpenFilePicker) {
      setExcelSyncStatus("This browser cannot save directly to the fixed Excel file. Open the dashboard in Chrome or Edge.", "error");
      return;
    }

    if (!workbookHandle) {
      workbookHandle = await window.TermChecklistExcel.openWorkbookPicker();
      await setWorkbookBaseline(null);
      try {
        await window.TermChecklistExcel.saveHandle(workbookHandle);
      } catch (error) {
        console.warn("The workbook is linked for this browser session only.", error);
      }
    }

    workbookWriteEnabled = await requestWorkbookPermission(workbookHandle, "readwrite");
    if (!workbookWriteEnabled) throw new Error("Allow the dashboard to edit Term Checklist.xlsx, then click Save to Excel again.");

    window.clearTimeout(workbookSaveTimer);
    const snapshot = JSON.parse(JSON.stringify(employees));
    setExcelSyncStatus(`Saving to ${window.TermChecklistExcel.workbookName}...`);
    const result = await enqueueWorkbookSync(snapshot);
    if (!result.ok) return;
    workbookAutoSync = true;
    const mergeNote = result.remoteChanged ? " Latest Excel changes were merged." : "";
    setExcelSyncStatus(`Saved ${result.records.length} records to ${window.TermChecklistExcel.workbookName}.${mergeNote}`);
  } catch (error) {
    if (error?.name === "AbortError") return;
    setExcelSyncStatus(error.message || "The Excel checklist could not be saved.", "error");
  }
}

async function loadFallbackExcelFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  if (file.name !== window.TermChecklistExcel.workbookName) {
    setExcelSyncStatus(`Choose ${window.TermChecklistExcel.workbookName} from the dashboard folder.`, "error");
    return;
  }

  try {
    const importedEmployees = await window.TermChecklistExcel.loadFile(file, CHECKLIST_ITEMS);
    workbookHandle = null;
    await setWorkbookBaseline(null);
    workbookWriteEnabled = false;
    await applyExcelRecords(importedEmployees, false);
  } catch (error) {
    setExcelSyncStatus(error.message || "The Excel checklist could not be loaded.", "error");
  }
}

async function requestWorkbookPermission(handle, mode) {
  if (!handle.queryPermission || !handle.requestPermission) return false;
  let permission = await handle.queryPermission({ mode });
  if (permission !== "granted") {
    try {
      permission = await handle.requestPermission({ mode });
    } catch (error) {
      return false;
    }
  }
  return permission === "granted";
}

async function applyExcelRecords(importedRecords, linkedFile) {
  const importedEmployees = removeJohnDoeRecords(importedRecords);

  if (employees.length && !importedEmployees.length) {
    if (workbookBaselineRecords?.length) {
      const replaceWithEmpty = window.confirm(
        `Term Checklist.xlsx now has no employee records. Replace the ${employees.length} browser records with the empty Excel version? Export CSV first if you need to keep the browser copy.`
      );
      if (!replaceWithEmpty) {
        workbookAutoSync = false;
        setExcelSyncStatus("Browser records were preserved. Excel is empty; nothing was written.", "warning");
        return;
      }

      await setWorkbookBaseline(importedEmployees);
      employees = [];
      workbookAutoSync = Boolean(linkedFile && workbookWriteEnabled);
      workbookImportBusy = true;
      saveEmployees();
      workbookImportBusy = false;
      render();
      if (workbookAutoSync) {
        const result = await enqueueWorkbookSync(cloneEmployeeRecords(employees));
        if (result.ok) setExcelSyncStatus("Loaded the empty Excel checklist. Future changes will sync automatically.");
      } else if (linkedFile) {
        setExcelSyncStatus("Loaded the empty Excel checklist. Click Save to Excel to grant edit access.", "warning");
      } else {
        setExcelSyncStatus("Loaded the empty Excel checklist. Changes are saved in this browser only.", "warning");
      }
      return;
    }

    const saveCurrent = window.confirm(
      `Term Checklist.xlsx is empty. Save the ${employees.length} employee records currently in this browser to the Excel file?`
    );
    if (!saveCurrent) {
      workbookAutoSync = false;
      setExcelSyncStatus("The dashboard data was left as-is. The empty Excel file was not changed.", "warning");
      return;
    }
    if (linkedFile && workbookWriteEnabled) {
      await setWorkbookBaseline(importedEmployees);
      const result = await enqueueWorkbookSync(cloneEmployeeRecords(employees));
      if (!result.ok) return;
      workbookAutoSync = true;
      setExcelSyncStatus(`Saved ${result.records.length} browser records to ${window.TermChecklistExcel.workbookName}.`);
    } else {
      await setWorkbookBaseline(importedEmployees);
      setExcelSyncStatus("This browser can import the file but cannot save changes back to it.", "warning");
    }
    return;
  }

  const importMerge = mergeEmployeeRecords(workbookBaselineRecords || [], employees, importedEmployees);
  if (importMerge.conflicts.length) {
    const useExcelVersions = window.confirm(
      `${importMerge.conflicts.length} employee record(s) changed in both places. Nothing was overwritten. Use the Excel version for those records? Export CSV first if you need to keep the browser versions.`
    );
    if (!useExcelVersions) {
      workbookAutoSync = false;
      setExcelSyncStatus("Sync paused. No records were overwritten. Export CSV, then load again when ready to use Excel's versions.", "warning");
      return;
    }

    const reconciled = new Map(importMerge.records.map((record) => [record.id, record]));
    importMerge.conflicts.forEach((id) => {
      const excelRecord = importedEmployees.find((record) => record.id === id);
      if (excelRecord) reconciled.set(id, excelRecord);
      else reconciled.delete(id);
    });
    importMerge.records = [...reconciled.values()];
  }

  await setWorkbookBaseline(importedEmployees);
  employees = importMerge.records;
  expandedEmployeeIds = new Set();
  workbookAutoSync = Boolean(linkedFile && workbookWriteEnabled);
  workbookImportBusy = true;
  saveEmployees();
  workbookImportBusy = false;
  render();

  if (workbookAutoSync) {
    try {
      const result = await enqueueWorkbookSync(cloneEmployeeRecords(employees));
      if (result.ok) {
        setExcelSyncStatus(`Loaded and reconciled ${employees.length} records. Changes will save to ${window.TermChecklistExcel.workbookName}.`);
      }
    } catch (error) {
      setExcelSyncStatus("Loaded the workbook, but it could not be updated. Close it in Excel and click Load from destination again.", "warning");
      console.warn("Excel workbook sync failed.", error);
    }
  } else if (linkedFile) {
    setExcelSyncStatus(`Loaded ${employees.length} records. Click Save to Excel to grant edit access and enable automatic saving.`, "warning");
  } else {
    setExcelSyncStatus(`Loaded ${employees.length} records. Changes are saved in this browser only.`, "warning");
  }
}

function employeeRecordsMatch(first, second) {
  const project = (records) => records.map((employee) => ({
    id: employee.id,
    terminationDate: employee.terminationDate || "",
    employeeName: employee.employeeName || "",
    employeeId: employee.employeeId || "",
    department: employee.department || "",
    supervisor: employee.supervisor || "",
    hrOwner: employee.hrOwner || "",
    notes: employee.notes || "",
    conditionalDetails: employee.conditionalDetails || {},
    tasks: Object.fromEntries(CHECKLIST_ITEMS.map((item) => {
      const task = employee.tasks?.[item.id] || {};
      return [item.id, { status: task.status || "Open", dueDate: task.dueDate || "", notes: task.notes || "" }];
    }))
  })).sort((a, b) => a.id.localeCompare(b.id));

  return JSON.stringify(project(first)) === JSON.stringify(project(second));
}

function cloneEmployeeRecords(records) {
  return JSON.parse(JSON.stringify(records || []));
}

async function setWorkbookBaseline(records) {
  workbookBaselineRecords = Array.isArray(records) ? cloneEmployeeRecords(records) : null;
  try {
    await window.TermChecklistExcel.saveBaseline(workbookBaselineRecords);
  } catch (error) {
    console.warn("The last Excel sync snapshot could not be saved.", error);
  }
}

function mergeEmployeeRecords(baselineRecords, localRecords, excelRecords) {
  const baseline = new Map((baselineRecords || []).map((record) => [record.id, record]));
  const local = new Map((localRecords || []).map((record) => [record.id, record]));
  const excel = new Map((excelRecords || []).map((record) => [record.id, record]));
  const merged = [];
  const conflicts = [];
  const ids = new Set([...baseline.keys(), ...local.keys(), ...excel.keys()]);
  const sameRecord = (first, second) => employeeRecordsMatch([first], [second]);

  ids.forEach((id) => {
    const baseRecord = baseline.get(id);
    const localRecord = local.get(id);
    const excelRecord = excel.get(id);

    if (!baseRecord) {
      if (localRecord && excelRecord && !sameRecord(localRecord, excelRecord)) {
        conflicts.push(id);
      } else if (localRecord || excelRecord) {
        merged.push(localRecord || excelRecord);
      }
      return;
    }

    if (!localRecord && !excelRecord) return;
    if (!localRecord) {
      if (sameRecord(excelRecord, baseRecord)) return;
      conflicts.push(id);
      return;
    }
    if (!excelRecord) {
      if (sameRecord(localRecord, baseRecord)) return;
      conflicts.push(id);
      return;
    }
    if (sameRecord(localRecord, excelRecord)) {
      merged.push(localRecord);
    } else if (sameRecord(localRecord, baseRecord)) {
      merged.push(excelRecord);
    } else if (sameRecord(excelRecord, baseRecord)) {
      merged.push(localRecord);
    } else {
      conflicts.push(id);
    }
  });

  return { records: merged, conflicts };
}

async function syncWorkbookSnapshot(localSnapshot) {
  const excelRecords = removeJohnDoeRecords(
    await window.TermChecklistExcel.loadWorkbook(workbookHandle, CHECKLIST_ITEMS)
  );
  const localRecords = employeeRecordsMatch(employees, localSnapshot)
    ? localSnapshot
    : cloneEmployeeRecords(employees);
  const baseline = workbookBaselineRecords;
  const merge = mergeEmployeeRecords(baseline || [], localRecords, excelRecords);

  if (merge.conflicts.length) {
    workbookAutoSync = false;
    setExcelSyncStatus(
      `Sync paused: ${merge.conflicts.length} employee record(s) changed in both places. Nothing was overwritten. Export CSV, then load the Excel version to reconcile.`,
      "warning"
    );
    return { ok: false, conflicts: merge.conflicts };
  }

  const remoteChanged = baseline !== null && !employeeRecordsMatch(baseline, excelRecords);
  const mergedRecords = cloneEmployeeRecords(merge.records);
  if (!employeeRecordsMatch(employees, mergedRecords)) {
    workbookImportBusy = true;
    employees = mergedRecords;
    saveEmployees();
    workbookImportBusy = false;
    render();
  }

  await window.TermChecklistExcel.writeWorkbook(workbookHandle, mergedRecords, CHECKLIST_ITEMS);
  await setWorkbookBaseline(mergedRecords);
  return { ok: true, records: mergedRecords, remoteChanged };
}

function enqueueWorkbookSync(snapshot) {
  const operation = workbookSaveQueue.catch(() => {}).then(() => syncWorkbookSnapshot(snapshot));
  workbookSaveQueue = operation;
  return operation;
}

function scheduleWorkbookSave() {
  if (workbookImportBusy || !workbookHandle || !workbookAutoSync) return;
  if (!workbookWriteEnabled) {
    setExcelSyncStatus("Browser changes are saved locally. Click Load from destination to grant Excel access.", "warning");
    return;
  }

  window.clearTimeout(workbookSaveTimer);
  setExcelSyncStatus(`Saving changes to ${window.TermChecklistExcel.workbookName}...`);
  workbookSaveTimer = window.setTimeout(() => {
    if (workbookImportBusy) return;
    const snapshot = JSON.parse(JSON.stringify(employees));
    enqueueWorkbookSync(snapshot).then((result) => {
      if (!result.ok) return;
      const message = result.remoteChanged
        ? `Merged latest Excel changes and saved to ${window.TermChecklistExcel.workbookName}.`
        : `Saved to ${window.TermChecklistExcel.workbookName}.`;
      setExcelSyncStatus(message);
    }).catch((error) => {
      setExcelSyncStatus("Browser changes are saved locally. Close the workbook in Excel, then click Save to Excel to retry.", "warning");
      console.warn("Excel workbook sync failed.", error);
    });
  }, 450);
}

function setExcelSyncStatus(message, tone = "") {
  if (!dom.excelSyncStatus) return;
  dom.excelSyncStatus.textContent = message;
  dom.excelSyncStatus.classList.toggle("is-warning", tone === "warning");
  dom.excelSyncStatus.classList.toggle("is-error", tone === "error");
}

function render() {
  renderOwnerOptions();
  const filteredEmployees = getFilteredEmployees();
  renderKpis();
  renderChecklistRows(filteredEmployees);
  dom.recordCount.textContent = `${filteredEmployees.length} of ${employees.length} employee records shown`;
  dom.lastSaved.textContent = `${employees.length} records saved locally`;
}

function renderBoardHeader() {
  dom.boardHeader.innerHTML = `
    <th scope="col">Employee</th>
    <th scope="col">Progress</th>
    <th scope="col">Critical items</th>
    <th scope="col">Finance items</th>
    <th scope="col">Next due</th>
  `;
}

function renderOwnerOptions() {
  const currentOwner = dom.ownerFilter.value || "All";
  const owners = [...new Set(employees.map((employee) => employee.hrOwner).filter(Boolean))].sort();
  const ownerOptions = owners.map((owner) => {
    return `<option value="${escapeAttr(owner)}">${escapeHtml(owner)}</option>`;
  }).join("");

  dom.ownerFilter.innerHTML = `<option value="All">All owners</option>${ownerOptions}`;
  dom.ownerFilter.value = owners.includes(currentOwner) ? currentOwner : "All";
}

function renderKpis() {
  const stats = calculateStats();
  const cards = [
    {
      label: "Active terminations",
      value: stats.activeTerminations,
      detail: `${employees.length} total employee records`,
      tone: "teal"
    },
    {
      label: "Checklist completion",
      value: `${stats.completionRate}%`,
      detail: `${stats.completedTasks}/${stats.applicableTasks} applicable tasks complete`,
      tone: "green"
    },
    {
      label: "Critical open items",
      value: stats.criticalOpen,
      detail: "IT, Dayforce, badge, and clearance",
      tone: stats.criticalOpen ? "red" : "green"
    },
    {
      label: "Finance follow-ups",
      value: stats.financeOpen,
      detail: "Tuition, bonus, and PTO items",
      tone: stats.financeOpen ? "amber" : "green"
    },
    {
      label: "Overdue tasks",
      value: stats.overdueTasks,
      detail: "Open items past due date",
      tone: stats.overdueTasks ? "red" : "green"
    },
    {
      label: "Security readouts",
      value: stats.securityOpen,
      detail: "Clearance readouts not complete",
      tone: stats.securityOpen ? "violet" : "green"
    }
  ];

  dom.kpiGrid.innerHTML = cards.map((card) => {
    return `
      <article class="kpi-card tone-${card.tone}">
        <span class="kpi-label">${escapeHtml(card.label)}</span>
        <strong>${escapeHtml(String(card.value))}</strong>
        <span class="kpi-detail">${escapeHtml(card.detail)}</span>
      </article>
    `;
  }).join("");
}

function renderChecklistRows(records) {
  if (!records.length) {
    const hasRecords = employees.length > 0;
    dom.checklistBody.innerHTML = `
      <tr>
        <td class="empty-state" colspan="5">
          <div class="empty-state-content">
            <strong>${hasRecords ? "No employee records match the current filters." : "No termination records yet."}</strong>
            <span>${hasRecords ? "Clear a filter or search for another employee." : "Add an employee above to start a termination checklist."}</span>
            ${hasRecords ? "" : '<button class="button button-secondary" type="button" data-scroll-to-form>Add your first employee</button>'}
          </div>
        </td>
      </tr>
    `;
    return;
  }

  dom.checklistBody.innerHTML = records.map((employee) => {
    const summary = getEmployeeSummary(employee);
    const isExpanded = expandedEmployeeIds.has(employee.id);

    return `
      <tr class="employee-summary-row ${isExpanded ? "is-expanded" : ""}">
        <td class="employee-cell" data-label="Employee">
          <button
            class="employee-name-button"
            type="button"
            data-expand-employee-id="${escapeAttr(employee.id)}"
            aria-expanded="${isExpanded}"
            aria-controls="employee-detail-${escapeAttr(employee.id)}"
          >
            <span class="expand-mark" aria-hidden="true">${isExpanded ? "-" : "+"}</span>
            <span>${escapeHtml(employee.employeeName)}</span>
          </button>
          <div class="employee-meta">
            <span>ID ${escapeHtml(employee.employeeId)}</span>
            <span>${escapeHtml(employee.department)} | Term ${formatDisplayDate(employee.terminationDate)}</span>
            <span>Supervisor: ${escapeHtml(employee.supervisor || "Unassigned")}</span>
            <span>HR owner: ${escapeHtml(employee.hrOwner)}</span>
          </div>
        </td>
        <td class="summary-cell" data-label="Progress">
          <div class="progress-wrap" aria-label="${summary.completionRate}% complete">
            <span>${summary.completedTasks}/${summary.applicableTasks} complete</span>
            <div class="progress-track"><div class="progress-fill" style="width: ${summary.completionRate}%"></div></div>
          </div>
          ${renderTermCompleteCheckbox(employee, summary)}
        </td>
        <td class="summary-cell" data-label="Critical items">
          ${renderSummaryPills(summary.criticalOpenItems, "critical")}
        </td>
        <td class="summary-cell" data-label="Finance items">
          ${renderSummaryPills(summary.financeOpenItems, "finance")}
        </td>
        <td class="summary-cell" data-label="Next due">
          ${renderDueSummary(summary)}
        </td>
      </tr>
      ${isExpanded ? renderEmployeeDetailRow(employee, summary) : ""}
    `;
  }).join("");
}

function renderEmployeeDetailRow(employee, summary) {
  const taskCards = CHECKLIST_ITEMS.map((item) => renderTaskCard(employee, item)).join("");
  const detailBadges = [
    { label: `${summary.openTasks} open`, tone: summary.openTasks ? "amber" : "green" },
    { label: `${summary.blockedTasks} blocked`, tone: summary.blockedTasks ? "red" : "muted" },
    { label: `${summary.overdueTasks} overdue`, tone: summary.overdueTasks ? "red" : "muted" }
  ].map((badge) => `<span class="detail-badge tone-${badge.tone}">${escapeHtml(badge.label)}</span>`).join("");

  return `
    <tr class="employee-detail-row">
      <td colspan="5">
        <section class="employee-detail-panel" id="employee-detail-${escapeAttr(employee.id)}" aria-label="${escapeAttr(employee.employeeName)} checklist details">
          <div class="detail-header">
            <div>
              <h3>${escapeHtml(employee.employeeName)}</h3>
              <p>${escapeHtml(employee.department)} | Employee ID ${escapeHtml(employee.employeeId)} | Term ${formatDisplayDate(employee.terminationDate)}</p>
            </div>
            <div class="detail-side">
              <div class="employee-action-group" aria-label="${escapeAttr(employee.employeeName)} actions">
                <button class="button button-small button-secondary" type="button" data-edit-employee-id="${escapeAttr(employee.id)}">Edit employee</button>
                <button class="button button-small button-danger" type="button" data-delete-employee-id="${escapeAttr(employee.id)}">Delete employee</button>
              </div>
              ${renderTermCompleteCheckbox(employee, summary)}
              <div class="detail-badges">${detailBadges}</div>
            </div>
          </div>

          <div class="detail-info-grid">
            <span><strong>Supervisor</strong>${escapeHtml(employee.supervisor || "Unassigned")}</span>
            <span><strong>HR owner</strong>${escapeHtml(employee.hrOwner || "Unassigned")}</span>
            <span><strong>Checklist</strong>${summary.completedTasks}/${summary.applicableTasks} applicable tasks complete</span>
            <span><strong>Next due</strong>${summary.nextDueDate ? formatDisplayDate(summary.nextDueDate) : "No open due dates"}</span>
          </div>

          ${employee.notes ? `<p class="detail-notes">${escapeHtml(employee.notes)}</p>` : ""}

          <div class="expanded-task-grid">
            ${taskCards}
          </div>
        </section>
      </td>
    </tr>
  `;
}

function renderTaskCard(employee, item) {
  const task = getTask(employee, item.id);
  const isTaskOverdue = isOverdue(task);
  const statusClass = `status-${statusSlug(task.status)}`;
  const options = STATUS_OPTIONS.map((status) => {
    return `<option value="${escapeAttr(status)}" ${status === task.status ? "selected" : ""}>${escapeHtml(status)}</option>`;
  }).join("");

  return `
    <article class="task-card">
      <div class="task-card-header">
        <div>
          <h4>${escapeHtml(item.label)}</h4>
          <span>${escapeHtml(item.category)}</span>
        </div>
        ${isTaskOverdue ? `<span class="overdue-label">Overdue</span>` : ""}
      </div>
      <div class="task-editor">
        <label>
          Status
          <select
            class="status-select ${statusClass}"
            data-task-field="status"
            data-employee-id="${escapeAttr(employee.id)}"
            data-task-id="${escapeAttr(item.id)}"
            aria-label="${escapeAttr(item.label)} status for ${escapeAttr(employee.employeeName)}"
          >
            ${options}
          </select>
        </label>
        <label>
          Due date
          <input
            type="date"
            value="${escapeAttr(task.dueDate || "")}"
            data-task-field="dueDate"
            data-employee-id="${escapeAttr(employee.id)}"
            data-task-id="${escapeAttr(item.id)}"
            aria-label="${escapeAttr(item.label)} due date for ${escapeAttr(employee.employeeName)}"
          >
        </label>
        <label>
          Task notes
          <textarea
            class="task-note"
            rows="3"
            data-task-field="notes"
            data-employee-id="${escapeAttr(employee.id)}"
            data-task-id="${escapeAttr(item.id)}"
            aria-label="${escapeAttr(item.label)} note for ${escapeAttr(employee.employeeName)}"
            placeholder="Task note"
          >${escapeHtml(task.notes || "")}</textarea>
        </label>
      </div>
    </article>
  `;
}

function renderTermCompleteCheckbox(employee, summary) {
  return `
    <label class="term-complete-control ${summary.termComplete ? "is-complete" : ""}">
      <input
        type="checkbox"
        data-complete-term-id="${escapeAttr(employee.id)}"
        ${summary.termComplete ? "checked" : ""}
        aria-label="Mark ${escapeAttr(employee.employeeName)} term complete"
      >
      <span>Term complete</span>
    </label>
  `;
}

function saveEmployeeForm(event) {
  event.preventDefault();
  const formData = new FormData(dom.employeeForm);

  if (editingEmployeeId) {
    updateEmployee(formData);
    return;
  }

  addEmployee(formData);
}

function addEmployee(formData) {
  const employee = createEmployeeFromForm(formData);

  employees.unshift(employee);
  expandedEmployeeIds.add(employee.id);
  saveEmployees();
  dom.employeeForm.reset();
  setDefaultTerminationDate();
  updateConditionalFields();
  render();
}

function updateEmployee(formData) {
  const employeeIndex = employees.findIndex((employee) => employee.id === editingEmployeeId);
  if (employeeIndex < 0) return;

  employees[employeeIndex] = createEmployeeFromForm(formData, employees[employeeIndex]);
  expandedEmployeeIds.add(editingEmployeeId);
  saveEmployees();
  dom.employeeForm.reset();
  setDefaultTerminationDate();
  updateConditionalFields();
  render();
}

function createEmployeeFromForm(formData, existingEmployee = null) {
  const terminationDate = getFormValue(formData, "terminationDate");
  const conditionalDetails = {
    tuition: {
      enabled: formData.get("hasTuition") === "on",
      amount: getFormValue(formData, "tuitionAmount"),
      dueDate: getFormValue(formData, "tuitionDue"),
      note: getFormValue(formData, "tuitionNote")
    },
    bonus: {
      enabled: formData.get("hasBonus") === "on",
      amount: getFormValue(formData, "bonusAmount"),
      dueDate: getFormValue(formData, "bonusDue"),
      note: getFormValue(formData, "bonusNote")
    },
    clearance: {
      enabled: formData.get("hasClearance") === "on",
      program: getFormValue(formData, "clearanceProgram"),
      dueDate: getFormValue(formData, "clearanceDue"),
      note: getFormValue(formData, "clearanceNote")
    },
    pto: {
      enabled: formData.get("hasPto") === "on",
      hours: getFormValue(formData, "ptoHours"),
      dueDate: getFormValue(formData, "ptoDue"),
      note: getFormValue(formData, "ptoNote")
    }
  };
  const now = new Date().toISOString();

  return {
    id: existingEmployee?.id || createId(),
    terminationDate,
    employeeName: getFormValue(formData, "employeeName"),
    employeeId: getFormValue(formData, "employeeId"),
    department: getFormValue(formData, "department"),
    supervisor: getFormValue(formData, "supervisor"),
    hrOwner: getFormValue(formData, "hrOwner"),
    notes: getFormValue(formData, "notes"),
    conditionalDetails,
    tasks: existingEmployee ? updateConditionalTasks(existingEmployee, conditionalDetails) : buildDefaultTasks(terminationDate, conditionalDetails),
    createdAt: existingEmployee?.createdAt || now,
    updatedAt: now
  };
}

function updateConditionalTasks(employee, conditionalDetails) {
  const tasks = {};
  const fallbacks = {
    tuition: "Confirm reimbursement status and payroll handling.",
    bonus: "Review one-year sign-on bonus agreement.",
    clearance: "Complete required security clearance readout.",
    pto: "Confirm PTO balance and payroll deduction."
  };

  CHECKLIST_ITEMS.forEach((item) => {
    const existingTask = { ...getTask(employee, item.id) };
    const detail = item.conditional ? conditionalDetails[item.conditional] : null;

    if (!item.conditional) {
      tasks[item.id] = existingTask;
      return;
    }

    if (!detail?.enabled) {
      tasks[item.id] = { status: "N/A", dueDate: "", notes: "" };
      return;
    }

    if (existingTask.status === "N/A") {
      tasks[item.id] = conditionalTask(detail, fallbacks[item.conditional]);
      return;
    }

    tasks[item.id] = {
      ...existingTask,
      dueDate: detail.dueDate || existingTask.dueDate,
      notes: detail.note || existingTask.notes
    };
  });

  return tasks;
}

function buildDefaultTasks(terminationDate, conditionalDetails) {
  const baseDue = terminationDate || toISO(new Date());

  return {
    it: { status: "Open", dueDate: baseDue, notes: "Disable access and collect hardware." },
    dayforce: { status: "Open", dueDate: baseDue, notes: "Finalize Dayforce termination workflow." },
    badge: { status: "Open", dueDate: baseDue, notes: "Collect badge or deactivate building access." },
    cleanout: { status: "Open", dueDate: addDaysISO(baseDue, 2), notes: "Coordinate workspace cleanout." },
    tuition: conditionalTask(conditionalDetails.tuition, "Confirm reimbursement status and payroll handling."),
    bonus: conditionalTask(conditionalDetails.bonus, "Review one-year sign-on bonus agreement."),
    clearance: conditionalTask(conditionalDetails.clearance, "Complete required security clearance readout."),
    pto: conditionalTask(conditionalDetails.pto, "Confirm PTO balance and payroll deduction.")
  };
}

function conditionalTask(detail, fallbackNote) {
  if (!detail?.enabled) {
    return { status: "N/A", dueDate: "", notes: "" };
  }

  const detailParts = [];
  if (detail.amount) detailParts.push(`Amount: ${formatCurrency(detail.amount)}`);
  if (detail.hours) detailParts.push(`Hours: ${detail.hours}`);
  if (detail.program) detailParts.push(`Program: ${detail.program}`);
  if (detail.note) detailParts.push(detail.note);

  return {
    status: "Open",
    dueDate: detail.dueDate || toISO(new Date()),
    notes: detailParts.length ? detailParts.join(" | ") : fallbackNote
  };
}

function updateChecklistField(event) {
  const control = event.target.closest("[data-task-field]");
  if (!control) return;

  const { employeeId, taskId, taskField } = control.dataset;
  const employee = employees.find((record) => record.id === employeeId);
  if (!employee) return;

  if (!employee.tasks[taskId]) {
    employee.tasks[taskId] = { status: "Open", dueDate: "", notes: "" };
  }

  employee.tasks[taskId][taskField] = control.value;
  employee.updatedAt = new Date().toISOString();
  saveEmployees();
  render();
}

function completeTermFromCheckbox(event) {
  const checkbox = event.target.closest("[data-complete-term-id]");
  if (!checkbox) return;

  const employee = employees.find((record) => record.id === checkbox.dataset.completeTermId);
  if (!employee) return;

  if (!checkbox.checked) {
    render();
    return;
  }

  employee.tasks = employee.tasks || {};

  CHECKLIST_ITEMS.forEach((item) => {
    const task = getTask(employee, item.id);
    employee.tasks[item.id] = { ...task };

    if (employee.tasks[item.id].status !== "N/A") {
      employee.tasks[item.id].status = "Complete";
    }
  });

  employee.updatedAt = new Date().toISOString();
  saveEmployees();
  render();
}

function toggleEmployeeExpansion(event) {
  const button = event.target.closest("[data-expand-employee-id]");
  if (!button) return;

  const employeeId = button.dataset.expandEmployeeId;

  if (expandedEmployeeIds.has(employeeId)) {
    expandedEmployeeIds.delete(employeeId);
  } else {
    expandedEmployeeIds.add(employeeId);
  }

  render();
}

function focusEmployeeForm(event) {
  const button = event.target.closest("[data-scroll-to-form]");
  if (!button) return;

  dom.employeeForm.scrollIntoView({ behavior: "smooth", block: "start" });
  window.setTimeout(() => dom.employeeForm.elements.employeeName?.focus(), 250);
}

function handleEmployeeActions(event) {
  const editButton = event.target.closest("[data-edit-employee-id]");
  if (editButton) {
    editEmployee(editButton.dataset.editEmployeeId);
    return;
  }

  const deleteButton = event.target.closest("[data-delete-employee-id]");
  if (deleteButton) {
    deleteEmployee(deleteButton.dataset.deleteEmployeeId);
  }
}

function editEmployee(employeeId) {
  const employee = employees.find((record) => record.id === employeeId);
  if (!employee) return;

  const elements = dom.employeeForm.elements;
  const details = employee.conditionalDetails || {};

  editingEmployeeId = employee.id;
  elements.terminationDate.value = employee.terminationDate || "";
  elements.employeeName.value = employee.employeeName || "";
  elements.employeeId.value = employee.employeeId || "";
  elements.department.value = employee.department || "";
  elements.supervisor.value = employee.supervisor || "";
  elements.hrOwner.value = employee.hrOwner || "";
  elements.notes.value = employee.notes || "";

  populateConditionalFields(elements, details);
  setEmployeeFormMode(true);
  updateConditionalFields();
  dom.employeeForm.scrollIntoView({ behavior: "smooth", block: "start" });
  window.setTimeout(() => elements.employeeName.focus(), 250);
}

function populateConditionalFields(elements, details) {
  const fields = [
    { key: "tuition", toggle: "hasTuition", amount: "tuitionAmount", dueDate: "tuitionDue", note: "tuitionNote" },
    { key: "bonus", toggle: "hasBonus", amount: "bonusAmount", dueDate: "bonusDue", note: "bonusNote" },
    { key: "clearance", toggle: "hasClearance", program: "clearanceProgram", dueDate: "clearanceDue", note: "clearanceNote" },
    { key: "pto", toggle: "hasPto", hours: "ptoHours", dueDate: "ptoDue", note: "ptoNote" }
  ];

  fields.forEach((field) => {
    const detail = details[field.key] || {};
    elements[field.toggle].checked = Boolean(detail.enabled);

    if (field.amount) elements[field.amount].value = detail.amount || "";
    if (field.program) elements[field.program].value = detail.program || "";
    if (field.hours) elements[field.hours].value = detail.hours || "";
    elements[field.dueDate].value = detail.dueDate || "";
    elements[field.note].value = detail.note || "";
  });
}

function setEmployeeFormMode(isEditing) {
  dom.employeeFormEyebrow.textContent = isEditing ? "Edit Record" : "New Record";
  dom.employeeFormTitle.textContent = isEditing ? "Edit Employee" : "Add Employee";
  dom.employeeSubmitButton.textContent = isEditing ? "Save changes" : "Add employee";
  dom.cancelEditButton.hidden = !isEditing;
}

function cancelEdit() {
  dom.employeeForm.reset();
}

function deleteEmployee(employeeId) {
  const employee = employees.find((record) => record.id === employeeId);
  if (!employee) return;

  const confirmed = window.confirm(`Delete ${employee.employeeName}'s termination record? This cannot be undone.`);
  if (!confirmed) return;

  employees = employees.filter((record) => record.id !== employeeId);
  expandedEmployeeIds.delete(employeeId);

  if (editingEmployeeId === employeeId) {
    dom.employeeForm.reset();
  }

  saveEmployees();
  render();
}

function getEmployeeSummary(employee) {
  let completedTasks = 0;
  let applicableTasks = 0;
  let openTasks = 0;
  let blockedTasks = 0;
  let overdueTasks = 0;
  let nextDueDate = "";
  let nextDueLabel = "";
  const criticalOpenItems = [];
  const financeOpenItems = [];

  CHECKLIST_ITEMS.forEach((item) => {
    const task = getTask(employee, item.id);
    const isClosed = task.status === "Complete" || task.status === "N/A";

    if (task.status !== "N/A") {
      applicableTasks += 1;
    }

    if (task.status === "Complete") {
      completedTasks += 1;
    }

    if (!isClosed) {
      openTasks += 1;

      if (item.critical) {
        criticalOpenItems.push(item.label);
      }

      if (item.finance) {
        financeOpenItems.push(item.label);
      }

      if (task.dueDate && (!nextDueDate || parseISODate(task.dueDate) < parseISODate(nextDueDate))) {
        nextDueDate = task.dueDate;
        nextDueLabel = item.label;
      }
    }

    if (task.status === "Blocked") {
      blockedTasks += 1;
    }

    if (isOverdue(task)) {
      overdueTasks += 1;
    }
  });

  return {
    completedTasks,
    applicableTasks,
    openTasks,
    blockedTasks,
    overdueTasks,
    nextDueDate,
    nextDueLabel,
    criticalOpenItems,
    financeOpenItems,
    termComplete: applicableTasks > 0 && completedTasks === applicableTasks,
    completionRate: applicableTasks ? Math.round((completedTasks / applicableTasks) * 100) : 100
  };
}

function renderSummaryPills(items, tone) {
  if (!items.length) {
    return `<span class="summary-muted">None open</span>`;
  }

  const visibleItems = items.slice(0, 2);
  const remainingCount = items.length - visibleItems.length;
  const pills = visibleItems.map((item) => {
    return `<span class="summary-pill tone-${tone}">${escapeHtml(shortTaskLabel(item))}</span>`;
  });

  if (remainingCount) {
    pills.push(`<span class="summary-pill tone-muted">+${remainingCount}</span>`);
  }

  return pills.join("");
}

function renderDueSummary(summary) {
  if (!summary.nextDueDate) {
    return `<span class="summary-muted">No open due dates</span>`;
  }

  const dueClass = parseISODate(summary.nextDueDate) < startOfToday() ? "is-overdue" : "";

  return `
    <span class="due-date ${dueClass}">${formatDisplayDate(summary.nextDueDate)}</span>
    <span class="due-label">${escapeHtml(shortTaskLabel(summary.nextDueLabel))}</span>
  `;
}

function shortTaskLabel(label) {
  const labels = {
    "Office cleanout": "Cleanout",
    "Pending tuition check reimbursement": "Tuition",
    "Track one-year sign-on bonus": "Sign-on bonus",
    "Security clearance readout, if necessary": "Clearance",
    "Overdrawn paid time off": "Overdrawn PTO"
  };

  return labels[label] || label;
}

function getFilteredEmployees() {
  const searchTerm = dom.searchFilter.value.trim().toLowerCase();
  const owner = dom.ownerFilter.value;
  const status = dom.statusFilter.value;
  const criticalOnly = dom.criticalOnlyFilter.checked;

  return employees.filter((employee) => {
    const matchesSearch = !searchTerm || [
      employee.employeeName,
      employee.employeeId,
      employee.department,
      employee.supervisor,
      employee.hrOwner,
      employee.notes
    ].some((value) => String(value || "").toLowerCase().includes(searchTerm));

    const matchesOwner = owner === "All" || employee.hrOwner === owner;
    const matchesStatus = status === "All" || CHECKLIST_ITEMS.some((item) => getTask(employee, item.id).status === status);
    const matchesCritical = !criticalOnly || hasCriticalOpenItem(employee);

    return matchesSearch && matchesOwner && matchesStatus && matchesCritical;
  });
}

function calculateStats() {
  let activeTerminations = 0;
  let completedTasks = 0;
  let applicableTasks = 0;
  let criticalOpen = 0;
  let financeOpen = 0;
  let overdueTasks = 0;
  let securityOpen = 0;

  employees.forEach((employee) => {
    let employeeHasOpenTask = false;

    CHECKLIST_ITEMS.forEach((item) => {
      const task = getTask(employee, item.id);
      const isClosed = task.status === "Complete" || task.status === "N/A";
      const isApplicable = task.status !== "N/A";

      if (isApplicable) {
        applicableTasks += 1;
      }

      if (task.status === "Complete") {
        completedTasks += 1;
      }

      if (!isClosed) {
        employeeHasOpenTask = true;
      }

      if (item.critical && !isClosed) {
        criticalOpen += 1;
      }

      if (item.finance && !isClosed) {
        financeOpen += 1;
      }

      if (item.clearance && !isClosed) {
        securityOpen += 1;
      }

      if (isOverdue(task)) {
        overdueTasks += 1;
      }
    });

    if (employeeHasOpenTask) {
      activeTerminations += 1;
    }
  });

  const completionRate = applicableTasks ? Math.round((completedTasks / applicableTasks) * 100) : 0;

  return {
    activeTerminations,
    completedTasks,
    applicableTasks,
    completionRate,
    criticalOpen,
    financeOpen,
    overdueTasks,
    securityOpen
  };
}

function hasCriticalOpenItem(employee) {
  return CHECKLIST_ITEMS.some((item) => {
    const task = getTask(employee, item.id);
    return item.critical && task.status !== "Complete" && task.status !== "N/A";
  });
}

function getTask(employee, itemId) {
  return employee.tasks?.[itemId] || { status: "Open", dueDate: "", notes: "" };
}

function updateConditionalFields() {
  dom.employeeForm.querySelectorAll("[data-conditional-target]").forEach((toggle) => {
    const fields = document.querySelector(`#${toggle.dataset.conditionalTarget}`);
    if (fields) {
      fields.hidden = !toggle.checked;
    }
  });
}

function exportCsv() {
  const headers = [
    "Employee Name",
    "Employee ID",
    "Termination Date",
    "Department",
    "Supervisor",
    "HR Owner",
    "Employee Notes",
    "Tuition Reimbursement",
    "Tuition Amount",
    "Sign-On Bonus",
    "Bonus Amount",
    "Clearance Readout",
    "Overdrawn PTO",
    "PTO Hours",
    "Checklist Item",
    "Status",
    "Due Date",
    "Task Notes"
  ];

  const rows = employees.flatMap((employee) => {
    return CHECKLIST_ITEMS.map((item) => {
      const task = getTask(employee, item.id);
      const details = employee.conditionalDetails || {};

      return [
        employee.employeeName,
        employee.employeeId,
        employee.terminationDate,
        employee.department,
        employee.supervisor,
        employee.hrOwner,
        employee.notes,
        details.tuition?.enabled ? "Yes" : "No",
        details.tuition?.amount || "",
        details.bonus?.enabled ? "Yes" : "No",
        details.bonus?.amount || "",
        details.clearance?.enabled ? "Yes" : "No",
        details.pto?.enabled ? "Yes" : "No",
        details.pto?.hours || "",
        item.label,
        task.status,
        task.dueDate,
        task.notes
      ];
    });
  });

  const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const downloadLink = document.createElement("a");

  downloadLink.href = url;
  downloadLink.download = `termination-checklist-dashboard-${toISO(new Date())}.csv`;
  document.body.append(downloadLink);
  downloadLink.click();
  downloadLink.remove();
  URL.revokeObjectURL(url);
}

function setDefaultTerminationDate() {
  const dateInput = dom.employeeForm.elements.terminationDate;
  if (dateInput && !dateInput.value) {
    dateInput.value = toISO(new Date());
  }
}

function getFormValue(formData, key) {
  return String(formData.get(key) || "").trim();
}

function isOverdue(task) {
  if (!task.dueDate || task.status === "Complete" || task.status === "N/A") return false;
  return parseISODate(task.dueDate) < startOfToday();
}

function addDaysISO(isoDate, days) {
  const base = isoDate ? parseISODate(isoDate) : new Date();
  return toISO(addDays(base, days));
}

function addDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function startOfToday() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return today;
}

function parseISODate(isoDate) {
  const [year, month, day] = isoDate.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function toISO(date) {
  const adjusted = new Date(date);
  adjusted.setMinutes(adjusted.getMinutes() - adjusted.getTimezoneOffset());
  return adjusted.toISOString().slice(0, 10);
}

function formatDisplayDate(isoDate) {
  if (!isoDate) return "No date";
  return parseISODate(isoDate).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}

function formatCurrency(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return value;
  return number.toLocaleString(undefined, { style: "currency", currency: "USD" });
}

function statusSlug(status) {
  return String(status).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function createId() {
  if (window.crypto?.randomUUID) {
    return window.crypto.randomUUID();
  }

  return `record-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function csvEscape(value) {
  const text = String(value ?? "");
  if (/[",\r\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttr(value) {
  return escapeHtml(value);
}
