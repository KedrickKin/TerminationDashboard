(function () {
  const DB_NAME = "termination-checklist-dashboard-files";
  const DB_VERSION = 1;
  const HANDLE_STORE = "file-handles";
  const HANDLE_KEY = "term-checklist-workbook";
  const BASELINE_KEY = "term-checklist-baseline";
  const WORKBOOK_NAME = "Term Checklist.xlsx";
  const WORKSHEET_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
  const RELATIONSHIP_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
  const PACKAGE_RELATIONSHIP_NS = "http://schemas.openxmlformats.org/package/2006/relationships";
  const DAY_MS = 24 * 60 * 60 * 1000;

  const EMPLOYEE_HEADERS = [
    "Record ID", "Termination Date", "Employee Name", "Employee ID", "Department", "Supervisor", "HR Owner", "Notes",
    "Tuition Required", "Tuition Amount", "Tuition Due Date", "Tuition Note",
    "Sign-on Bonus Required", "Bonus Amount", "Bonus Review Due", "Bonus Note",
    "Security Readout Required", "Clearance Program", "Clearance Due Date", "Clearance Note",
    "Overdrawn PTO Required", "PTO Hours", "PTO Follow-up Due", "PTO Note"
  ];

  const TASK_HEADERS = ["Record ID", "Checklist Item ID", "Checklist Item", "Status", "Due Date", "Task Notes"];
  const STATUS_OPTIONS = ["Open", "In Progress", "Blocked", "Complete", "N/A"];

  async function openWorkbookPicker() {
    if (!window.showOpenFilePicker) {
      throw new Error("This browser cannot remember a workbook link. Open the dashboard in Chrome or Edge to use the one-click Excel connection.");
    }

    const [handle] = await window.showOpenFilePicker({
      id: "termination-checklist-workbook",
      startIn: "documents",
      multiple: false,
      types: [{
        description: "Termination checklist workbook",
        accept: { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"] }
      }]
    });

    if (handle.name !== WORKBOOK_NAME) {
      throw new Error(`Choose ${WORKBOOK_NAME} from the dashboard folder.`);
    }

    return handle;
  }

  async function loadWorkbook(handle, checklistItems) {
    const file = await handle.getFile();
    return loadFile(file, checklistItems);
  }

  async function loadFile(file, checklistItems) {
    if (!window.JSZip) throw new Error("Excel support did not load. Reopen the dashboard from its index link.");
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const worksheetPaths = await getWorksheetPaths(zip);
    const employeesPath = worksheetPaths.get("Employees");
    const tasksPath = worksheetPaths.get("Checklist Items");

    if (!employeesPath || !tasksPath) {
      throw new Error("The workbook needs the Employees and Checklist Items sheets. Use the Term Checklist.xlsx template beside this dashboard.");
    }

    const sharedStrings = await getSharedStrings(zip);
    const employeeRows = await readWorksheet(zip, employeesPath, sharedStrings);
    const taskRows = await readWorksheet(zip, tasksPath, sharedStrings);
    return recordsFromRows(employeeRows, taskRows, checklistItems);
  }

  async function writeWorkbook(handle, employees, checklistItems) {
    if (!window.JSZip) throw new Error("Excel support did not load. Reopen the dashboard from its index link.");
    const file = await handle.getFile();
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const worksheetPaths = await getWorksheetPaths(zip);
    const employeesPath = worksheetPaths.get("Employees");
    const tasksPath = worksheetPaths.get("Checklist Items");

    if (!employeesPath || !tasksPath) {
      throw new Error("The linked workbook no longer has its required sheets.");
    }

    const employeeRows = [EMPLOYEE_HEADERS, ...employees.map(employeeToRow)];
    const taskRows = [TASK_HEADERS, ...employees.flatMap((employee) => checklistItems.map((item) => taskToRow(employee, item)))];

    await replaceWorksheetRows(zip, employeesPath, employeeRows);
    await replaceWorksheetRows(zip, tasksPath, taskRows);
    await resizeWorksheetTables(zip, employeesPath, EMPLOYEE_HEADERS.length, employeeRows.length - 1);
    await resizeWorksheetTables(zip, tasksPath, TASK_HEADERS.length, taskRows.length - 1);

    const output = await zip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 6 } });
    const writable = await handle.createWritable();
    await writable.write(output);
    await writable.close();
  }

  async function getSavedHandle() {
    return getStoredValue(HANDLE_KEY);
  }

  async function getSavedBaseline() {
    return getStoredValue(BASELINE_KEY);
  }

  async function getStoredValue(key) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(HANDLE_STORE, "readonly");
      const request = transaction.objectStore(HANDLE_STORE).get(key);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error || new Error("The saved Excel link could not be read."));
      transaction.oncomplete = () => db.close();
      transaction.onerror = () => {
        db.close();
        reject(transaction.error || new Error("The saved Excel link could not be read."));
      };
    });
  }

  async function saveHandle(handle) {
    return saveStoredValue(HANDLE_KEY, handle);
  }

  async function saveBaseline(records) {
    return saveStoredValue(BASELINE_KEY, records);
  }

  async function saveStoredValue(key, value) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(HANDLE_STORE, "readwrite");
      transaction.objectStore(HANDLE_STORE).put(value, key);
      transaction.oncomplete = () => {
        db.close();
        resolve();
      };
      transaction.onerror = () => {
        db.close();
        reject(transaction.error || new Error("The browser could not remember the Excel file."));
      };
    });
  }

  function openDatabase() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        reject(new Error("This browser cannot remember the Excel file link."));
        return;
      }

      const request = window.indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(HANDLE_STORE)) {
          request.result.createObjectStore(HANDLE_STORE);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("The Excel file link could not be saved."));
    });
  }

  async function getWorksheetPaths(zip) {
    const workbookFile = zip.file("xl/workbook.xml");
    const relationshipsFile = zip.file("xl/_rels/workbook.xml.rels");
    if (!workbookFile || !relationshipsFile) throw new Error("This file is not a readable Excel workbook.");

    const workbookXml = parseXml(await workbookFile.async("string"));
    const relationshipsXml = parseXml(await relationshipsFile.async("string"));
    const relationshipTargets = new Map();

    elementsByName(relationshipsXml, "Relationship").forEach((relationship) => {
      relationshipTargets.set(relationship.getAttribute("Id"), relationship.getAttribute("Target"));
    });

    const paths = new Map();
    elementsByName(workbookXml, "sheet").forEach((sheet) => {
      const relationshipId = sheet.getAttributeNS(RELATIONSHIP_NS, "id") || sheet.getAttribute("r:id");
      const target = relationshipTargets.get(relationshipId);
      if (target) paths.set(sheet.getAttribute("name"), resolvePackagePath("xl/workbook.xml", target));
    });

    return paths;
  }

  async function getSharedStrings(zip) {
    const file = zip.file("xl/sharedStrings.xml");
    if (!file) return [];

    const xml = parseXml(await file.async("string"));
    return elementsByName(xml, "si").map((stringItem) => {
      return elementsByName(stringItem, "t").map((text) => text.textContent || "").join("");
    });
  }

  async function readWorksheet(zip, path, sharedStrings) {
    const file = zip.file(path);
    if (!file) throw new Error(`The workbook sheet file is missing: ${path}`);

    const xml = parseXml(await file.async("string"));
    const sheetData = firstElementByName(xml, "sheetData");
    if (!sheetData) return [];

    return elementsByName(sheetData, "row").map((row) => {
      const values = [];
      elementsByName(row, "c").forEach((cell) => {
        const address = cell.getAttribute("r") || "";
        const column = columnIndexFromAddress(address);
        if (column < 0) return;
        values[column] = readCellValue(cell, sharedStrings);
      });
      return values;
    });
  }

  function readCellValue(cell, sharedStrings) {
    const type = cell.getAttribute("t");
    if (type === "inlineStr") {
      const inlineString = firstElementByName(cell, "is");
      return inlineString ? elementsByName(inlineString, "t").map((text) => text.textContent || "").join("") : "";
    }

    const valueElement = firstElementByName(cell, "v");
    if (!valueElement) return "";
    const raw = valueElement.textContent || "";

    if (type === "s") return sharedStrings[Number(raw)] || "";
    if (type === "b") return raw === "1";
    if (type === "str") return raw;

    const number = Number(raw);
    return raw !== "" && Number.isFinite(number) ? number : raw;
  }

  function recordsFromRows(employeeRows, taskRows, checklistItems) {
    const employeeRecords = rowsAsObjects(employeeRows);
    const taskRecords = rowsAsObjects(taskRows);
    const employees = [];
    const byRecordId = new Map();

    employeeRecords.forEach((row) => {
      const employeeName = asText(row["Employee Name"]);
      if (!employeeName || employeeName.trim().toLowerCase() === "john doe") return;

      let id = asText(row["Record ID"]).trim();
      if (!id) id = createRecordId();
      if (byRecordId.has(id)) throw new Error(`Duplicate Record ID in Employees sheet: ${id}`);

      const terminationDate = dateToIso(row["Termination Date"]);
      const conditionalDetails = {
        tuition: {
          enabled: isEnabled(row["Tuition Required"]),
          amount: asText(row["Tuition Amount"]),
          dueDate: dateToIso(row["Tuition Due Date"]),
          note: asText(row["Tuition Note"])
        },
        bonus: {
          enabled: isEnabled(row["Sign-on Bonus Required"]),
          amount: asText(row["Bonus Amount"]),
          dueDate: dateToIso(row["Bonus Review Due"]),
          note: asText(row["Bonus Note"])
        },
        clearance: {
          enabled: isEnabled(row["Security Readout Required"]),
          program: asText(row["Clearance Program"]),
          dueDate: dateToIso(row["Clearance Due Date"]),
          note: asText(row["Clearance Note"])
        },
        pto: {
          enabled: isEnabled(row["Overdrawn PTO Required"]),
          hours: asText(row["PTO Hours"]),
          dueDate: dateToIso(row["PTO Follow-up Due"]),
          note: asText(row["PTO Note"])
        }
      };

      const employee = {
        id,
        terminationDate,
        employeeName: employeeName.trim(),
        employeeId: asText(row["Employee ID"]),
        department: asText(row.Department),
        supervisor: asText(row.Supervisor),
        hrOwner: asText(row["HR Owner"]),
        notes: asText(row.Notes),
        conditionalDetails,
        tasks: defaultTasks(terminationDate, conditionalDetails, checklistItems),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      employees.push(employee);
      byRecordId.set(id, employee);
    });

    const itemById = new Map(checklistItems.map((item) => [item.id, item]));
    const itemByLabel = new Map(checklistItems.map((item) => [item.label, item]));

    taskRecords.forEach((row) => {
      const recordId = asText(row["Record ID"]).trim();
      const employee = byRecordId.get(recordId);
      if (!employee) return;

      const item = itemById.get(asText(row["Checklist Item ID"]).trim()) || itemByLabel.get(asText(row["Checklist Item"]).trim());
      if (!item) return;

      const statusValue = asText(row.Status).trim();
      const status = STATUS_OPTIONS.find((option) => option.toLowerCase() === statusValue.toLowerCase()) || "Open";
      employee.tasks[item.id] = {
        status,
        dueDate: dateToIso(row["Due Date"]),
        notes: asText(row["Task Notes"])
      };
    });

    return employees;
  }

  function rowsAsObjects(rows) {
    if (rows.length < 2) return [];
    const headers = rows[0].map((header) => asText(header).trim());

    return rows.slice(1).map((row) => {
      const record = {};
      headers.forEach((header, index) => {
        if (header) record[header] = row[index] ?? "";
      });
      return record;
    }).filter((record) => Object.values(record).some((value) => value !== "" && value != null));
  }

  function defaultTasks(terminationDate, conditionalDetails, checklistItems) {
    const baseDate = terminationDate || toIso(new Date());
    const defaultNotes = {
      it: "Disable access and collect hardware.",
      dayforce: "Finalize Dayforce termination workflow.",
      badge: "Collect badge or deactivate building access.",
      cleanout: "Coordinate workspace cleanout.",
      tuition: "Confirm reimbursement status and payroll handling.",
      bonus: "Review one-year sign-on bonus agreement.",
      clearance: "Complete required security clearance readout.",
      pto: "Confirm PTO balance and payroll deduction."
    };

    return Object.fromEntries(checklistItems.map((item) => {
      const detail = item.conditional ? conditionalDetails[item.conditional] : null;
      if (detail && !detail.enabled) return [item.id, { status: "N/A", dueDate: "", notes: "" }];

      const dueDate = detail?.dueDate || (item.id === "cleanout" ? addDays(baseDate, 2) : baseDate);
      const parts = [];
      if (detail?.amount) parts.push(`Amount: ${formatCurrency(detail.amount)}`);
      if (detail?.hours) parts.push(`Hours: ${detail.hours}`);
      if (detail?.program) parts.push(`Program: ${detail.program}`);
      if (detail?.note) parts.push(detail.note);

      return [item.id, { status: "Open", dueDate, notes: parts.length ? parts.join(" | ") : defaultNotes[item.id] || "" }];
    }));
  }

  function employeeToRow(employee) {
    const details = employee.conditionalDetails || {};
    return [
      employee.id, employee.terminationDate, employee.employeeName, employee.employeeId, employee.department, employee.supervisor, employee.hrOwner, employee.notes,
      details.tuition?.enabled ? "Yes" : "No", numericOrText(details.tuition?.amount), details.tuition?.dueDate, details.tuition?.note,
      details.bonus?.enabled ? "Yes" : "No", numericOrText(details.bonus?.amount), details.bonus?.dueDate, details.bonus?.note,
      details.clearance?.enabled ? "Yes" : "No", details.clearance?.program, details.clearance?.dueDate, details.clearance?.note,
      details.pto?.enabled ? "Yes" : "No", numericOrText(details.pto?.hours), details.pto?.dueDate, details.pto?.note
    ];
  }

  function taskToRow(employee, item) {
    const task = employee.tasks?.[item.id] || { status: "Open", dueDate: "", notes: "" };
    return [employee.id, item.id, item.label, task.status, task.dueDate, task.notes];
  }

  async function replaceWorksheetRows(zip, path, rows) {
    const file = zip.file(path);
    if (!file) throw new Error(`The workbook sheet file is missing: ${path}`);

    const xml = parseXml(await file.async("string"));
    const sheetData = firstElementByName(xml, "sheetData");
    if (!sheetData) throw new Error("A workbook sheet is missing its cell data.");

    const oldRows = elementsByName(sheetData, "row");
    const headerStyles = styleMap(oldRows.find((row) => row.getAttribute("r") === "1"));
    const bodyStyles = styleMap(oldRows.find((row) => row.getAttribute("r") === "2"));
    const columnCount = rows[0].length;
    const persistedRows = rows.length === 1 ? [...rows, Array(columnCount).fill("")] : rows;

    while (sheetData.firstChild) sheetData.removeChild(sheetData.firstChild);
    persistedRows.forEach((values, rowIndex) => {
      const rowNumber = rowIndex + 1;
      const row = xml.createElementNS(WORKSHEET_NS, "row");
      row.setAttribute("r", String(rowNumber));

      values.forEach((value, columnIndex) => {
        const cell = xml.createElementNS(WORKSHEET_NS, "c");
        cell.setAttribute("r", `${columnName(columnIndex)}${rowNumber}`);
        const styleId = (rowNumber === 1 ? headerStyles : bodyStyles).get(columnIndex);
        if (styleId) cell.setAttribute("s", styleId);
        writeCellValue(xml, cell, value, rows[0][columnIndex]);
        row.appendChild(cell);
      });

      sheetData.appendChild(row);
    });

    const dimension = firstElementByName(xml, "dimension");
    if (dimension) dimension.setAttribute("ref", `A1:${columnName(columnCount - 1)}${persistedRows.length}`);

    zip.file(path, new XMLSerializer().serializeToString(xml));
  }

  function writeCellValue(xml, cell, value, header) {
    if (value === null || value === undefined || value === "") return;

    if (isDateHeader(header)) {
      const serial = isoToExcelSerial(value);
      if (serial !== null) {
        const valueNode = xml.createElementNS(WORKSHEET_NS, "v");
        valueNode.textContent = String(serial);
        cell.appendChild(valueNode);
        return;
      }
    }

    if (typeof value === "number" && Number.isFinite(value)) {
      const valueNode = xml.createElementNS(WORKSHEET_NS, "v");
      valueNode.textContent = String(value);
      cell.appendChild(valueNode);
      return;
    }

    const text = typeof value === "boolean" ? (value ? "Yes" : "No") : String(value);
    cell.setAttribute("t", "inlineStr");
    const inline = xml.createElementNS(WORKSHEET_NS, "is");
    const textNode = xml.createElementNS(WORKSHEET_NS, "t");
    if (/^\s|\s$/.test(text)) textNode.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
    textNode.textContent = text;
    inline.appendChild(textNode);
    cell.appendChild(inline);
  }

  async function resizeWorksheetTables(zip, sheetPath, columnCount, recordCount) {
    const relationshipsPath = relationshipPathForSheet(sheetPath);
    const relationshipsFile = zip.file(relationshipsPath);
    const sheetFile = zip.file(sheetPath);
    if (!relationshipsFile || !sheetFile) return;

    const [relationshipsXml, sheetXml] = await Promise.all([
      relationshipsFile.async("string").then(parseXml),
      sheetFile.async("string").then(parseXml)
    ]);
    const relationshipTargets = new Map();
    elementsByName(relationshipsXml, "Relationship").forEach((relationship) => {
      relationshipTargets.set(relationship.getAttribute("Id"), relationship.getAttribute("Target"));
    });

    const tableParts = firstElementByName(sheetXml, "tableParts");
    if (!tableParts) return;
    const rowCount = Math.max(2, recordCount + 1);
    const ref = `A1:${columnName(columnCount - 1)}${rowCount}`;

    for (const part of elementsByName(tableParts, "tablePart")) {
      const relationshipId = part.getAttributeNS(RELATIONSHIP_NS, "id") || part.getAttribute("r:id");
      const target = relationshipTargets.get(relationshipId);
      if (!target) continue;

      const tablePath = resolvePackagePath(sheetPath, target);
      const tableFile = zip.file(tablePath);
      if (!tableFile) continue;
      const tableXml = parseXml(await tableFile.async("string"));
      const table = firstElementByName(tableXml, "table");
      if (!table) continue;
      table.setAttribute("ref", ref);
      const filter = firstElementByName(table, "autoFilter");
      if (filter) filter.setAttribute("ref", ref);
      zip.file(tablePath, new XMLSerializer().serializeToString(tableXml));
    }
  }

  function styleMap(row) {
    const styles = new Map();
    if (!row) return styles;

    elementsByName(row, "c").forEach((cell) => {
      const styleId = cell.getAttribute("s");
      const column = columnIndexFromAddress(cell.getAttribute("r") || "");
      if (styleId && column >= 0) styles.set(column, styleId);
    });
    return styles;
  }

  function parseXml(text) {
    const xml = new DOMParser().parseFromString(text, "application/xml");
    if (firstElementByName(xml, "parsererror")) throw new Error("The Excel document contains invalid XML.");
    return xml;
  }

  function firstElementByName(parent, name) {
    return elementsByName(parent, name)[0] || null;
  }

  function elementsByName(parent, name) {
    if (!parent) return [];
    return Array.from(parent.getElementsByTagNameNS ? parent.getElementsByTagNameNS("*", name) : parent.getElementsByTagName(name));
  }

  function relationshipPathForSheet(sheetPath) {
    const slash = sheetPath.lastIndexOf("/");
    return `${sheetPath.slice(0, slash)}/_rels/${sheetPath.slice(slash + 1)}.rels`;
  }

  function resolvePackagePath(sourcePath, target) {
    const base = target.startsWith("/") ? [] : sourcePath.slice(0, sourcePath.lastIndexOf("/")).split("/");
    const parts = [...base, ...target.replace(/^\//, "").split("/")];
    const normalized = [];
    parts.forEach((part) => {
      if (!part || part === ".") return;
      if (part === "..") normalized.pop();
      else normalized.push(part);
    });
    return normalized.join("/");
  }

  function isEnabled(value) {
    if (value === true) return true;
    return ["yes", "true", "1", "required"].includes(asText(value).trim().toLowerCase());
  }

  function asText(value) {
    return value === null || value === undefined ? "" : String(value);
  }

  function dateToIso(value) {
    if (value === "" || value === null || value === undefined) return "";
    if (typeof value === "number" && value > 0 && value < 2958466) {
      return toIso(new Date(Date.UTC(1899, 11, 30) + value * DAY_MS));
    }

    const text = String(value).trim();
    const iso = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;

    const parsed = new Date(text);
    return Number.isNaN(parsed.getTime()) ? "" : toIso(parsed);
  }

  function isoToExcelSerial(value) {
    const iso = dateToIso(value);
    if (!iso) return null;
    const date = new Date(`${iso}T00:00:00.000Z`);
    return Math.round((date.getTime() - Date.UTC(1899, 11, 30)) / DAY_MS);
  }

  function isDateHeader(header) {
    return /date|due$|due date/i.test(String(header || ""));
  }

  function toIso(date) {
    return date.toISOString().slice(0, 10);
  }

  function addDays(iso, amount) {
    const date = new Date(`${iso}T00:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + amount);
    return toIso(date);
  }

  function formatCurrency(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number.toLocaleString(undefined, { style: "currency", currency: "USD" }) : String(value);
  }

  function numericOrText(value) {
    if (value === "" || value === null || value === undefined) return "";
    const number = Number(value);
    return Number.isFinite(number) ? number : String(value);
  }

  function createRecordId() {
    return window.crypto?.randomUUID?.() || `record-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function columnIndexFromAddress(address) {
    const letters = String(address).match(/^[A-Z]+/i)?.[0];
    if (!letters) return -1;
    let value = 0;
    for (const letter of letters.toUpperCase()) value = value * 26 + letter.charCodeAt(0) - 64;
    return value - 1;
  }

  function columnName(index) {
    let result = "";
    let value = index + 1;
    while (value > 0) {
      const remainder = (value - 1) % 26;
      result = String.fromCharCode(65 + remainder) + result;
      value = Math.floor((value - 1) / 26);
    }
    return result;
  }

  window.TermChecklistExcel = {
    getSavedBaseline,
    getSavedHandle,
    loadFile,
    loadWorkbook,
    openWorkbookPicker,
    saveBaseline,
    saveHandle,
    writeWorkbook,
    workbookName: WORKBOOK_NAME
  };
})();
