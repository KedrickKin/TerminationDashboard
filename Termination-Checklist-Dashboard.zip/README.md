# Termination Checklist Dashboard

A standalone HR operations dashboard for tracking employee termination tasks. It runs from local files in a browser; no installation, command line, or web server is required.

## Open the Dashboard

1. Extract the ZIP file completely. Do not run the dashboard from inside the ZIP preview.
2. Keep `index.html` and the `termination-checklist-dashboard` folder together.
3. Double-click the `index.html` at the top of the extracted folder. It opens the dashboard in your browser. If needed, open `termination-checklist-dashboard/index.html` directly.
4. Use a current version of Microsoft Edge or Google Chrome for the remembered Excel connection and direct workbook saving.

Keep the included folder structure intact. The dashboard needs its JavaScript, stylesheet, bundled Excel library, and `Term Checklist.xlsx` beside its own `index.html`.

## First-Time Excel Connection

The included `termination-checklist-dashboard/Term Checklist.xlsx` is a blank workbook template with the `Employees` and `Checklist Items` sheets. The dashboard starts with no employee records; it does not include sample employees.

1. Open the dashboard and click **Load from destination**.
2. The first time, choose the included `Term Checklist.xlsx` from the extracted `termination-checklist-dashboard` folder. The browser's file picker may start in Documents; navigate to the extracted folder.
3. Approve the browser's read and edit permissions when prompted. The browser remembers the selected file for later use in that browser profile. It may ask you to grant permission again later.
4. Click **Load from destination** whenever you want to bring in the latest workbook changes. Use **Save to Excel** to check and save current dashboard changes to the workbook.

Do not rename the workbook or its two sheets. Keep the column headers and layout intact if you edit it directly in Excel. The dashboard expects the workbook name `Term Checklist.xlsx`.

## Daily Use

### Add an Employee

Fill in the termination date, employee name, employee ID, department, supervisor, HR owner, and notes in **Add Employee**. Turn on any applicable tuition reimbursement, sign-on bonus, security clearance, or overdrawn PTO options to show their detail fields. Submit the form to add the record.

### Update a Checklist

Click an employee's name in the board to expand their row. Each employee has these eight checklist items:

- IT
- Dayforce
- Badge
- Office cleanout
- Pending tuition check reimbursement
- Track one-year sign-on bonus
- Security clearance readout, if necessary
- Overdrawn paid time off

For each item, edit its status, due date, and task notes. Statuses are **Open**, **In Progress**, **Blocked**, **Complete**, and **N/A**. Conditional items default to **N/A** unless enabled for that employee.

The **Term complete** checkbox marks every applicable checklist item **Complete** and leaves **N/A** items unchanged. To correct a task afterward, change that item's status directly.

### Edit, Delete, Filter, and Export

- Use **Edit employee** in the expanded row to update employee details. Use **Delete employee** to remove that employee and their checklist.
- Search by employee name, ID, department, supervisor, HR owner, or notes. The owner and status menus and the critical-items filter can narrow the board; **Clear filters** resets them.
- **Export CSV** downloads all employee checklist records, including task status, due date, and notes. It exports all employees, not only the currently filtered rows.
- **Reset form** clears the form fields; it does not delete employee records.

## Saving and Syncing

The dashboard saves changes automatically to browser `localStorage`. This is a local copy for the current browser profile on the current device; it is not shared automatically with other people or browsers.

When an Excel workbook is linked and edit permission is granted, dashboard changes are also saved to that workbook. Before writing, the dashboard rereads the workbook and compares it with the last synced baseline. Independent changes can be merged. If the same employee record changed in both places, sync pauses rather than silently replacing one version. Export a CSV backup before resolving a conflict; loading the Excel version can replace the conflicting browser version after confirmation.

### Important Multi-User Limitation

Conflict checks help with ordinary sequential edits, but an Excel file in OneDrive or another synced folder is not a transactional database. Two people can write at nearly the same time, or cloud synchronization can be delayed, so this setup cannot guarantee that every simultaneous edit is preserved. For the strongest protection with this file-based setup, coordinate who edits at a given time, load the workbook before starting, and save/load again after changes. Keep backups.

Guaranteed multi-user consistency requires an approved shared service with server-side transactions or version checks, such as an organization-approved database or application platform. Do not treat browser `localStorage` as a shared team data store.

## Backups and Sensitive Data

- Export CSV regularly, especially before resolving a conflict or making a bulk change.
- Keep a separate copy of `Term Checklist.xlsx` before major changes. To restore a backup, close the dashboard, replace the workbook with the backup, and keep the restored file named `Term Checklist.xlsx`.
- Employee termination records may contain sensitive HR information. Store the extracted folder and backups only in organization-approved locations with appropriate access controls. Browser `localStorage` is not encrypted by this app.
- Moving the extracted folder or using another device/browser may require selecting the workbook again. The workbook file is the shareable copy; local browser storage and remembered file permissions are not.

## Troubleshooting

- **Excel file picker asks again:** Select the included `Term Checklist.xlsx` and grant permission. Browser permissions can expire or be revoked.
- **Workbook cannot be loaded:** Confirm the selected file is named `Term Checklist.xlsx` and contains sheets named `Employees` and `Checklist Items`. Restore the original template if the workbook structure was changed.
- **Browser cannot save to Excel:** Open the dashboard in current Edge or Chrome and grant edit access. Some browser or organization policies may allow import but block direct saving; the dashboard will indicate when changes remain browser-local.
- **Sync paused with a conflict:** Export CSV first, then use **Load from destination** and review the confirmation before choosing the Excel version. Do not continue editing both copies independently until reconciled.
- **Dashboard appears empty:** Check that you opened the intended extracted copy. Browser-local records belong to the browser profile that created them; click **Load from destination** to import records from the workbook.

## Package Contents

- `index.html` — top-level launcher
- `termination-checklist-dashboard/index.html` — dashboard page
- `termination-checklist-dashboard/app.js` — dashboard behavior and browser storage
- `termination-checklist-dashboard/excel-storage.js` — workbook import/export and remembered file link
- `termination-checklist-dashboard/styles.css` — responsive layout and styling
- `termination-checklist-dashboard/Term Checklist.xlsx` — blank Excel workbook
- `termination-checklist-dashboard/vendor/` — bundled JSZip library and its license
